import pandas as pd

vuelos = pd.read_csv('vuelos.csv')
trabajadores = pd.read_csv('trabajadores.csv')

# printea los primeros 5 datos de la data
# print(vuelos.head())
# print(trabajadores.head())

# printea las columnas especificas de la data
#print(vuelos[["vuelo_id", "nombre_compania"]])

trabajadores_pilotos = trabajadores[(trabajadores["rol"] == "Piloto") | (trabajadores["rol"] == "Copiloto")]
# print(trabajadores_pilotos.head())
trabajadores_tripulacion = trabajadores[(trabajadores["rol"] != "Piloto") & (trabajadores["rol"] != "Copiloto")]
trabajadores_tripulacion = trabajadores_tripulacion.drop(['licencia_actual_id'], axis=1)
# print(trabajadores_pilotos)
# print(trabajadores["rol"] == "Piloto")
trabajadores_pilotos.to_csv('trabajadores_pilotos.csv', index = False)
trabajadores_tripulacion.to_csv('trabajadores_tripulacion.csv', index = False)

